
function solicitarLogout(){
	//Enviar datos - Funciones de XMLHttpRequest
	//1. Crear: Comprar el sobre
	var carta = new XMLHttpRequest();
	//2. Configurar: Privacidad, Dirección y Mensaje
	carta.open("GET","logout.php",true);
	//3. Envío: 
	carta.send(null);

	//Recibir respuesta del servidor - Atributos de XMLHttpRequest
	carta.onreadystatechange = function() {
		if(carta.readyState == 4 && carta.status == 200){
			
			switch(carta.responseText){
				case "OK":
					alert('Su sesion ha sido cerrada. Será redirigido!')
					window.location.href = "index.html";
				break;
			}
		}
	}
}
