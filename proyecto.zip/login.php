<?php
	//Recibo parámetros por GET
	$usuario = $_GET["un"];
	$clave = $_GET["up"];
	//Encripto parámetros
	$claveE = hash("sha256", $clave);
	//CONEXIÓN CON NOTACIÓN FUNCIONAL
	//1. Llamar una función de conexión
	$conn = mysqli_connect("localhost","proyecto","Liga.Liga","proyecto");
	//2. Verificar conexión
	if(!$conn){
		//Hubo error en la conexión con la base de datos
		echo "ERROR";
	}else{
		//Conexión Correcta. Ejecuto mis comandos.
		//Configuración de la codificación de los carácteres
		mysqli_set_charset($conn, "utf8");
		//Redacto String con COMANDO SQL
		$select = "SELECT * FROM `usuario` WHERE `nombreUsuario`='$usuario' AND `clave`='$claveE'";
		//Ejecuto COMANDO SQL
		$resultado = mysqli_query($conn, $select);
		//Leo resultado
		//Resultado de un SELECT es una tabla
		//Cuento cantidad de Registros en la tabla de resultado
		if (mysqli_num_rows($resultado) > 0) {
			//Sí encontró al menos un registro con nombre y clave
			//Ciclo para recorrer conjunto de Resultados
			//Avanza de registro en registro de inicio a fin
			//Convierte cada registro enun arreglo asociativo, donde las llaves son los nombres de la columnas.
			while($arreglo=mysqli_fetch_assoc($resultado)){
				$usuarioID = $arreglo["usuarioId"];
				$usuarioNombre = $arreglo["nombreUsuario"];
			}
			//DATOS DE SESSION activa
			session_start();//Inicie/Active la sesión: NECESARIO ante de empezar a leer o escribir en $_SESSION
			$_SESSION["usuarioActivoID"] = $usuarioID;
			$_SESSION["usuarioActivoNombre"] = $usuarioNombre;
			//session_unset(); //Borrar los datos de $_SESSION
			//session_destroy();//Termine/Cierra la sesión
			echo "OK";
		}else{
			//No encontró ni un registro con nombre y clave
			$select = "SELECT * FROM `usuario` WHERE `nombreUsuario`='$usuario'";
			//Ejecuto COMANDO SQL Solo para nombre
			$resultado = mysqli_query($conn, $select);
			if (mysqli_num_rows($resultado) > 0) {
				//Encontró  nombre, por lo tanto, no existe nuestra clave para ese nombre
				echo "NOCLAVE";
			}else{
				//No encontró nombre
				echo "NOUSUARIO";
			}
		}
	}
	//echo "MENSAJE RECIBIDO: $usuario - $clave";
?>
