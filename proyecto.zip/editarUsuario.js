function cargarUsuario(){

	var search = location.search.substring(1);
	let parametrosQuery = JSON.parse('{"' + decodeURI(search).replace(/"/g, '\\"').replace(/&/g, '","').replace(/=/g,'":"') + '"}')

	//1. Crear: Comprar el sobre
	var carta = new XMLHttpRequest();
	//2. Configurar: Privacidad, Dirección y Mensaje
	carta.open("GET","obtenerUsuarioE.php?usuarioId="+parametrosQuery.usuarioId,true);
	//3. Envío:
	carta.send(null);

	//Recibir respuesta del servidor - Atributos de XMLHttpRequest
	carta.onreadystatechange = function() {
		if(carta.readyState == 4 && carta.status == 200){
			//document.getElementById("hContenido").innerHTML = carta.responseText;
			var div = document.getElementById("hContenido");

		    var data = JSON.parse(carta.responseText);
			document.getElementById("dUsuarioId").innerHTML = data[0].usuarioId;
			document.getElementById("usuarioId").value = data[0].usuarioId;			
			document.getElementById("nombreUsuario").value = data[0].nombreUsuario;
			document.getElementById("role").value = data[0].roleId;			
		}
	}
}

function almacenarRegistro() {
	var usuarioId = document.getElementById("usuarioId").value;
	var nombreUsuario = document.getElementById("nombreUsuario").value;
	var clave = document.getElementById("clave").value;
	var roleId = document.getElementById("role").value;
	
	if(verificarDatos()){
		enviaRegistro(usuarioId,nombreUsuario,clave,roleId);
	}
}

function verificarDatos(){

	var nombreUsuario = document.getElementById("nombreUsuario").value;
	var clave = document.getElementById("clave").value;
	
	if(nombreUsuario.trim().length < 8){
		alert('Por favor digite un valor correcto para el nombre de usuario! Al menos 8 caracteres');
		return false;
	}

	if(clave.trim().length < 8){
		alert('Por favor digite un valor correcto para la clave del usuario! Al menos 8 caracteres');
		return false;
	}

	return true;
}

function enviaRegistro(usuarioId,nombreUsuario,clave,roleId){
	var carta = new XMLHttpRequest();
	//2. (POST) Configurar: Privacidad, Dirección
	carta.open("POST","acccionMantenerUsuario.php",true);
	//2.5 (POST) Configurar: Encabezado HTTP
	carta.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	//3. (POST) Envío con Mensaje ( Parámetros )
	carta.send("usuarioId=" + usuarioId + "&nombreUsuario=" + nombreUsuario + "&clave=" + clave + "&roleId=" + roleId);
	//Recibir respuesta del servidor - Atributos de XMLHttpRequest
	//1. Moniterar y reaccionar cambios al readyState con el atributo onreadystatechange

	carta.onreadystatechange = function() {
		//2. Monitorear atributos:
		//	2.1. readyState: Es el estado del objeto XMLHttpRequest: 4 es recibido
		//	2.2. status: Es la recepción del mensaje por el servidor: 200 es OK
		if(carta.readyState == 4 && carta.status == 200){
			// 3. Respuesta recibida en el atributo responseText
			var respuesta = carta.responseText;

			if(respuesta == "ERROR"){
				alert("ERROR al intentar registrar el cambio en la Base de Datos");
			}else if(respuesta == "OK"){
				alert("El registro fue almacenado exitosamente en la Base de Datos");
				window.location.href = "usuarios.html";
			}
		}
	}
}

function eliminarUsuario() {
	var usuarioId = document.getElementById("usuarioId").value;
	
	if(confirm("Desea eliminar el usuario?")){
		enviaEliminarRegistro(usuarioId);
	}
}

function enviaEliminarRegistro(usuarioId){
	var carta = new XMLHttpRequest();
	//2. (POST) Configurar: Privacidad, Dirección
	carta.open("POST","acccionEliminarPlanta.php",true);
	//2.5 (POST) Configurar: Encabezado HTTP
	carta.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	//3. (POST) Envío con Mensaje ( Parámetros )
	carta.send("usuarioId=" + usuarioId);
	//Recibir respuesta del servidor - Atributos de XMLHttpRequest
	//1. Moniterar y reaccionar cambios al readyState con el atributo onreadystatechange
	carta.onreadystatechange = function() {
		//2. Monitorear atributos:
		//	2.1. readyState: Es el estado del objeto XMLHttpRequest: 4 es recibido
		//	2.2. status: Es la recepción del mensaje por el servidor: 200 es OK
		if(carta.readyState == 4 && carta.status == 200){
			// 3. Respuesta recibida en el atributo responseText
			var respuesta = carta.responseText;

			if(respuesta == "ERROR"){
				alert("ERROR al intentar eliminar el registro en la Base de Datos");
			}else if(respuesta == "OK"){
				alert("El registro fue eliminado exitosamente en la Base de Datos");
				window.location.href = "plantas.html";
			}
		}
	}
}