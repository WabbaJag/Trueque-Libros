Jose Miguel Carrillo Aguiluz
Joseph Adrián Zúñiga Brenes
Luis Jorge Hall Urrea
Yendri Carrillo Marchena
Frank Lin Chien