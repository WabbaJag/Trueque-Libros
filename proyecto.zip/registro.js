function registrar(){
	//console.log("Ingresar");
	var usuario = document.getElementById("campoUsuario").value;
	var clave = document.getElementById("campoClave").value;
	
	if(verificar()){
		enviarDatos(usuario,clave);
	}
}

function verificar(){
	var usuario = document.getElementById("campoUsuario").value;
	var clave = document.getElementById("campoClave").value;
	
	document.getElementById("parrafoInfo").innerHTML = "";
	
	if(usuario.length > 7 && clave.length>0){
		return true;
	}else{
		if(usuario.length <= 7){
			document.getElementById("parrafoInfo").innerHTML += "El usuario debe medir más de 8 carácteres."
		}
		if(clave.length==0){
			document.getElementById("parrafoInfo").innerHTML += "Debe ingresar una clave."
		}
		return false;
	}
}

function enviarDatos(user,pass){

	////PASOS PARA ENVIAR MENSAJES AL SERVIDOR (POST)
	//1. Crear: Comprar el sobre
	var carta = new XMLHttpRequest();
	//2. (POST) Configurar: Privacidad, Dirección
	carta.open("POST","registro.php",true);
	//2.5 (POST) Configurar: Encabezado HTTP
	carta.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	//3. (POST) Envío con Mensaje ( Parámetros )
	carta.send("un="+user+"&up="+pass);

	//Recibir respuesta del servidor - Atributos de XMLHttpRequest
	//1. Moniterar y reaccionar cambios al readyState con el atributo onreadystatechange
	carta.onreadystatechange = function() {
		//2. Monitorear atributos:
		//	2.1. readyState: Es el estado del objeto XMLHttpRequest: 4 es recibido
		//	2.2. status: Es la recepción del mensaje por el servidor: 200 es OK
		if(carta.readyState == 4 && carta.status == 200){
			// 3. Respuesta recibida en el atributo responseText
			
			var respuesta = carta.responseText;
			console.log(respuesta);
			if(respuesta == "ERROR"){
				alert("ERROR al registrar en Base de Datos");
				window.location.href = "index.html";
			}else if(respuesta == "OK"){
				window.location.href = "plantas.html";
			}
		}
	}
}