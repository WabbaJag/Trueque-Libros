<?php
  session_start();

	$conn = mysqli_connect("localhost","proyecto","Liga.Liga","proyecto");
	//2. Verificar conexión
	if(!$conn){
		//Hubo error en la conexión con la base de datos
		echo "ERROR en la coneccion a la base de datos";
	}else{

    $usuarioId = null;
    $accion = "";

    if (isset($_POST["usuarioId"])) {
      $usuarioId = trim($_POST['usuarioId']);
    }
        
    $nombreUsuario = $_POST['nombreUsuario'];
    $clave = $_POST['clave'];
    $roleId = $_POST['roleId'];

    $claveE = hash("sha256", $clave);

    mysqli_set_charset($conn, "utf8");

      if (!empty($usuarioId)) {
        $accion = "actualizado";
      //Conexión Correcta. Ejecuto mis comandos.
      //Configuración de la codificación de los carácteres
      
      //Redacto String con COMANDO SQL
      $comando = "UPDATE `usuario` SET nombreUsuario='" .$nombreUsuario . "', clave='" .$claveE . "', roleId=" .$roleId . " WHERE usuarioId=" . $usuarioId;
      //Ejecuto COMANDO SQL
      $resultado = mysqli_query($conn, $comando);

    } 
    mysqli_close($conn);

		if($resultado == true){
			echo "OK";
		}else{
			echo "ERROR";
		}
	}
?>