<?php
	$conn = mysqli_connect("localhost","proyecto","Liga.Liga","proyecto");
	//2. Verificar conexión
	if(!$conn){
		//Hubo error en la conexión con la base de datos
		echo "ERROR en la coneccion a la base de datos";
	}else{

    $productoId = null;
    $accion = "";

    if (isset($_POST["productoId"])) {
      $productoId = trim($_POST['productoId']);
    }

    mysqli_set_charset($conn, "utf8");

      if (!empty($productoId)) {
        $accion = "actualizado";
      //Conexión Correcta. Ejecuto mis comandos.
      //Configuración de la codificación de los carácteres
      
      //Redacto String con COMANDO SQL
      $comando = "DELETE FROM `producto` WHERE productoId=" . $productoId;
      //Ejecuto COMANDO SQL
      $resultado = mysqli_query($conn, $comando);

    }
    mysqli_close($conn);

		if($resultado == true){
			echo "OK";
		}else{
			echo "ERROR";
		}
	}
?>