<?php
  session_start();

	$conn = mysqli_connect("localhost","proyecto","Liga.Liga","proyecto");
	//2. Verificar conexión
	if(!$conn){
		//Hubo error en la conexión con la base de datos
		echo "ERROR en la coneccion a la base de datos";
	}else{

    $productoId = null;
    $accion = "";

    if (isset($_POST["productoId"])) {
      $productoId = trim($_POST['productoId']);
    }
        
    $nombre = $_POST['nombre'];
    $nombreCientifico = $_POST['nombreCientifico'];
    $descripcion = $_POST['descripcion'];
    $urlImagen = $_POST['urlImagen'];
    $creador = $_SESSION["usuarioActivoNombre"];

    mysqli_set_charset($conn, "utf8");

      if (!empty($productoId)) {
        $accion = "actualizado";
      //Conexión Correcta. Ejecuto mis comandos.
      //Configuración de la codificación de los carácteres
      
      //Redacto String con COMANDO SQL
      $comando = "UPDATE `producto` SET nombre='" .$nombre . "', nombreCientifico='" .$nombreCientifico . "', descripcion='" .$descripcion . "', urlImagen='" .$urlImagen . "', creador='" .$creador . "' WHERE productoId=" . $productoId;
      //Ejecuto COMANDO SQL
      $resultado = mysqli_query($conn, $comando);

    } else {
      $accion = "agregado";
      $comando = "INSERT INTO `producto`(nombre,nombreCientifico,descripcion,urlImagen,creador) VALUES ('" . $nombre . "','" .$nombreCientifico . "','" . $descripcion . "','" .$urlImagen . "','" . $creador . "')";
      //Ejecuto COMANDO SQL
      $resultado = mysqli_query($conn, $comando);
    }
    mysqli_close($conn);

		if($resultado == true){
			echo "OK";
		}else{
			echo "ERROR";
		}
	}
?>