<?php
	session_start();
	session_unset(); //Borrar los datos de $_SESSION
	session_destroy();//Termine/Cierra la sesión
	echo "OK";

?>
