<?php
	$conn = mysqli_connect("localhost","proyecto","Liga.Liga","proyecto");
	//2. Verificar conexión
	if(!$conn){
		//Hubo error en la conexión con la base de datos
		echo "ERROR en la coneccion a la base de datos";
	}else{

		$usuarioId = null;

    	if (isset($_GET["usuarioId"])) {
      	$usuarioId = $_GET["usuarioId"];
    	}

      	if (!empty($usuarioId)) {

		//Conexión Correcta. Ejecuto mis comandos.
		//Configuración de la codificación de los carácteres
		mysqli_set_charset($conn, "utf8");
		//Redacto String con COMANDO SQL
		$select = "SELECT * FROM `usuario` WHERE usuarioId = " . $usuarioId;
		//Ejecuto COMANDO SQL
		$resultado = mysqli_query($conn, $select);
		//Leo resultado
		//Resultado de un SELECT es una tabla
		//Cuento cantidad de Registros en la tabla de resultado
		}

    $arregloDatos = array();
		if (mysqli_num_rows($resultado) > 0) {
			//Sí encontró al menos un registro con nombre y clave
			//Ciclo para recorrer conjunto de Resultados
			//Avanza de registro en registro de inicio a fin
			//Convierte cada registro enun arreglo asociativo, donde las llaves son los nombres de la columnas.
      
      //$arregloDatos = mysqli_fetch_array($resultado);	
     // $arregloDatos = mysqli_fetch_assoc($resultado);	

     while($row = mysqli_fetch_array($resultado)){
      $arregloDatos[] = $row;
    }
		}
    header('Content-Type: application/json');
    echo json_encode($arregloDatos);
  }
?>