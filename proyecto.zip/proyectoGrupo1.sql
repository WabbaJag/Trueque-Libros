-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 24-04-2021 a las 16:47:15
-- Versión del servidor: 10.4.18-MariaDB
-- Versión de PHP: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `proyecto`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto`
--

CREATE TABLE `producto` (
  `productoId` int(11) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `descripcion` varchar(1000) NOT NULL,
  `nombreCientifico` varchar(100) NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `urlImagen` varchar(500) NOT NULL,
  `cantidad` int(11) NOT NULL DEFAULT 0,
  `creador` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `producto`
--

INSERT INTO `producto` (`productoId`, `nombre`, `descripcion`, `nombreCientifico`, `activo`, `urlImagen`, `cantidad`, `creador`) VALUES
(1, 'Albahaca', 'La albahaca es una hierba anual, cultivada como perenne en climas tropicales, de crecimiento bajo (entre 30 y 130 cm), con hojas opuestas de un verde lustroso, ovales u ovadas, dentadas y de textura sedosa, que miden de 3 a 11 cm de longitud por 1 a 6 cm de anchura. Emite espigas florales terminales, con flores tubulares de color blanco o violáceo las cuales, a diferencia de las del resto de la familia, tienen los cuatro estambres y el pistilo apoyados sobre el labio inferior de la corola. Tras la polinización entomófila, la corola se desprende y se desarrollan cuatro aquenios redondos en el interior del cáliz bilabiado.', 'Ocimum basilicum', 1, 'https://upload.wikimedia.org/wikipedia/commons/thumb/9/90/Basil-Basilico-Ocimum_basilicum-albahaca.jpg/260px-Basil-Basilico-Ocimum_basilicum-albahaca.jpg', 0, 'jcarrillo'),
(2, 'Planta Bromelia', '                La bromelia es una de las mejores plantas para poder cultivar en interiores; y es que la gran mayoría de las especies son capaces de prosperar a la sombra, por lo que no tendremos que estar comprobando en todo momento que recibe luz directa del sol.\r\n\r\nEsto puede parecer confuso en un primer momento, ya que es una planta tropical y, cómo seguro que ya sabes, las plantas tropicales suelen requerir de acción solar continua. Esta puede crecer a la perfección con sólo un poco de luz artificial.            ', 'brome', 1, 'https://www.compo.es/.imaging/focus/dam/global/plants/Bromelia---Bromelie-02.jpg/jcr:content.jpeg?lastModified=Fri+Jan+15+11%3A41%3A47+CET+2021', 0, 'ycarrillo'),
(3, 'Cola de caballo', '                                La cola de caballo se impone como un poderoso agente diurético y depurativo, tanto a nivel interno como externo, y no suele faltar de las más celebradas formulaciones herbarias que nos proponen los herbolarios expertos. Destaca así mismo como un potente regenerador celular por su contenido en sílice, lo que hace de ella uno de los mejores recursos herbarios para la reparación de los tejidos dañados. Toma nota de su variada acción terapéutica y déjate aconsejar para incluirla sin problemas en tus remedios naturales habituales.                  ', 'Equisetum bogotense', 0, 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoGBxQUExYTFBQYGBQZGyIdGxoaGRocIhwhJB0gIyIfIhwfHysiHCAoIiAdIzQjKCwuMTExICI3PDcvOyswMS4BCwsLDw4PHRERHTAoIigyMDAwMDAwMDkxMDswMjIyMDAyMDAwMDAwMDIwMDAwMjAwMDAwMDAwMjAwMDAwMDAwMP/AABEIAMIBAwMBIgACEQEDEQH/xAAbAAACAwEBAQAAAAAAAAAAAAAEBQADBgIBB//EAD8QAAIBAgQEBAQEBAYBAwUAAAECEQMhAAQSMQVBUWETInGBBjKRoUKxwfAUIzNSYnKC0eHxsjSSohVDU3Pi/8QAGgEAAwEBAQEAAAAAAAAAAAAAAQIDBAAFBv/EAC8RAAICAQMCBgEDAwUAAAAAAAABAhEhAxIxQVEEEyIyYXGBM5HwQqGxFCNiwdH/2gAMAwEAAhEDEQA/A', 0, 'ycarrillo'),
(4, 'Mastranzo', '             El mastranto es una variedad de menta conocida por sus beneficios nutricionales y sus propiedades anticancerígenas. Se utiliza para elaborar un aceite esencial ideal para tratar calambres, gripe, para preparar infusiones y hasta decorar postres. Algunas enfermedades que cura el mastranzo son: Antirreumática, antidiabética, eupéptica, hipotensora, hipostenizante vasculovenoso y vermífuga.', 'Lippia alba', 0, 'https://unisima.com/wp-content/uploads/2014/04/LA-MENTA-CONJUNTO-1.jpg', 0, 'ycarrillo'),
(5, 'Hierba de limón', '            Por lo general, el lemongrass se usa como hierba y saborizante en curries, sopas y pastas de curry. También es muy popular en su forma de té. En la cocina es recomendable eliminar todas las capas externas de la hierba dejando solo el tallo interior blanco y tierno, ya que ahí mismo se concentra todo el sabor. Por lo general, el lemongrass se usa como hierba y saborizante en curries, sopas y pastas de curry. También es muy popular en su forma de té. En la cocina es recomendable eliminar todas las capas externas de la hierba dejando solo el tallo interior blanco y tierno, ya que ahí mismo se concentra todo el sabor', '  Cymbopogon citratus', 0, 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoGBxQTExYUFBQXFxYYGSAcGRkZGh0fHBwfIh0dJCIhIB0cHyoiHB8qIiEdJDQjJysuMTExICI2OzYwOiowMS4BCwsLDw4PHRERHTAnIiczMzAwMDAwMjIwMjMyMDEwMDAwMDAyMDAwMDAwMDEwMDAwMDAwMDAwMDAwMDAwMDAwMP/AABEIALwBDAMBIgACEQEDEQH/xAAbAAADAQEBAQEAAAAAAAAAAAADBAUCAQYAB//EAEEQAAIBAgUBBgMGBQIFBAMBAAECEQMhAAQSMUFRBRMiYXGBMpGhBiNCUrHBFGJy0fDh8RUzgpKyQ2OiwlPS4iT/xAAYAQADAQEAAAAAAAAAAAAAAAAAAQIDBP/EACsRAAICAQQABQQCAwEAAAAAAAABAhEhAxIxQSJRYXHwgZGhsTLxE8Hh0f/aAAwDAQACEQMRAD8A8j9gk', 0, 'ycarrillo'),
(6, 'Menta', '              La menta principalmente por ser uso en la cocina como ingrediente en diversos platos, y por forma parte de la composición de algunos productos para la higiene bucal, esta planta no nos aporta solo su frescor, además ofrece múltiples beneficios para nuestra salud.\r\n\r\nLa rica composición de la menta hace de ella una planta con importantes propiedades saludables para nuestro organismo, sobre todo para el aparato respiratorio y el digestivo. De hecho, tan sólo su aroma posee la cualidad de refrescar las vías respiratorias y, al mismo tiempo, de estimular el apetito.', 'Mentha piperita', 0, 'https://www.hola.com/imagenes/estar-bien/20201020177484/propiedades-menta-remedio-casero/0-879-412/menta-a.jpg?filter=ds75', 0, 'ycarrillo'),
(7, 'Pata de vaca', ' En medicina popular se emplean las hojas de pata de vaca en infusión para el tratamiento de la diabetes no insulino- dependiente. Presentación comercial: se encuentra a la venta a granel y en gotas, recomendados para el tratamiento de la diabetes no insulino-dependiente.\r\nPosee propiedades medicinales excelentes útiles para tratar la Diabetes Mellitus, por sus efectos hipoglicemiante, y porque esta comprobado que disminuye el nivel de azúcar en la sangre. Esta hierba contiene proteínas y minerales como el potasio, el calcio, el fierro, el magnesio, el zinc y el cobre.', 'Bahunia caadicans', 0, 'https://i.pinimg.com/originals/dc/e7/fd/dce7fd0e2210d28ae10ffc9c59c292ab.jpg', 0, 'ycarrillo'),
(8, 'Contragavilana', '          La gavilana, capitana, botoncillo salvia cimarrona, retama o sepí (Neurolaena lobata) es una especie de arbusto de la familia Asteraceae que se encuentra en el bosque húmedo y en la vegetación de laderas y riscos, desde México hasta Bolivia y las Guayanas y en las Antillas, a menos de 1.500 m de altitud. Las hojas de la gavilana contienen principios activos que contribuyen a mitigar problemas estomacales, afecciones de la piel, bajar la fiebre, como diurético, etc. También puede utilizarse como repelente contra garrapatas.', 'Neurolaena lobata', 0, 'https://lh3.googleusercontent.com/proxy/ZuMaZb-9G5GR-P0Auogi_RylWjmdm1DQG8sv7XelVFhI7rRXHepq6UtkQxcztwjkJXb_EXrGkzrEYD8tSs31XTQdIoxYH11ej9jCd4cuLhXtDuB_qcqQSTFOymKhusdmKFzeUqqq4knMtN7mf3iInbnmzR-2FvOGz7sp1YrYF6ggpRkgnstVMw', 0, 'ycarrillo'),
(9, 'Balsamina', '                            Es una herbácea perenne que puede comportarse como anual en algunos climas. No suele sobrepasar los 60 cm de altura, con tallos acuosos y rectos muy ramificados. Las hojas, de color verde claro, son simples, alternas, de forma lanceolada o elíptica, tienen peciolos cortos y bordes muy aserrados.\r\n\r\nLas flores surgen en las axilas de las hojas en racimos sésiles de hasta tres flores. La corola está formada por dos labios superiores, tres sépalos, uno de ellos forma un tubo curvado lleno de néctar y tres pétalos desiguales en colores desde el blanco al amarillento o rojizo, aunque predominan los tonos rosas o púrpuras. Existen variedades simples, dobles o semidobles y su floración es muy abundante. El fruto es una cápsula ovoide que explota al tocarla esparciendo las semillas.', 'Momordica charantia', 0, 'https://i.ytimg.com/vi/iM5pJWFy3es/hq720.jpg?sqp=-oaymwEhCK4FEIIDSFryq4qpAxMIARUAAAAAGAElAADIQj0AgKJD&rs=AOn4CLCW-6vyDT5VCDfjtcryuPHysiBRcQ', 0, 'ycarrillo'),
(10, 'Ciclamen', '              El ciclamen es una planta originaria de los bosques del mediterráneo, caracterizándose por vivir a la sombra de los árboles durante el periodo invernal. Un exceso de calor o de iluminación puede ser letal para esta planta, podemos adaptarla tanto a interiores, cómo a exteriores sin ningún tipo de problema. Existen muchos tipos de ciclamen, caracterizándose en base al tamaño que alcanzarán, así como al tipo de hojas y de flores que presenten. ', 'Cyclamen', 0, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRpYtDJTshTZ-FzUMYCfjuln7-K_oDSYmjAWw&usqp=CAU', 0, 'ycarrillo'),
(11, 'Aloe vera', '                      Probablemente la planta de interior/exterior más conocida. Y es que está presente en la elaboración de prácticamente cualquier remedio, ya sea para arreglar nuestro pelo, para corregir algún estrago de la piel, incluso hasta tiene muchos beneficios para la salud. Esta planta se caracteriza por ser muy atractiva, es fácil de cuidar y muy estética      ', 'Aloe Vera', 0, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT1x_D1KE8srRYsxNzLXVmt__SaMnHDwfe49Q&usqp=CAU', 0, 'ycarrillo'),
(12, 'Acacia de la India', '                      La Fibra de Acacia, también conocida como Goma de Acacia, está hecha de la savia de un árbol que es autóctono de África. La savia está repleta de fibra soluble y ofrece muchos beneficios para la salud, como curar heridas, promover la salud bucal y aliviar la tos y el dolor de garganta.      ', 'Acacia angustifolia', 0, 'https://thumbs.dreamstime.com/z/ramas-rojas-hermosas-del-acacia-goa-de-la-india-54265784.jpg', 0, 'ycarrillo'),
(13, 'Ajenjo', '                El ajenjo, es una planta herbácea nativa de Latinoamérica, que también se da en las regiones templadas de Europa y África, tiene grandes beneficios, propiedades y usos medicinales que se ha usado por las civilizaciones más antiguas del planeta, se le considera una planta medicinal muy efectiva.\r\n\r\nEn la actualidad, el ajenjo es cultivado en distintos países gracias a su creciente popularidad y su gran habilidad para adaptarse a suelos pobres y en condiciones climáticas adversas.\r\n\r\nEsta planta posee un sabor amargo, producto de la absintina, uno de sus componentes. Sus propiedades medicinales tratan las afecciones gástricas y su uso medicinal es apto para cualquier persona, siguiendo siempre el consejo y las directrices de su médico.            ', 'Artemisia absinthium', 0, 'https://natureduca.com/images_med/med_ajenjo.jpg', 0, 'ycarrillo'),
(14, 'Alcachofa', '              La alcachofa es una planta medicinal que posee diversos beneficios, siendo capaz de disminuir el colesterol, ayudar en la pérdida de peso, combatir la anemia, combatir los gases y regular los niveles de azúcar en la sangre.\r\n\r\nSu nombre es Cynara scolymus, y la alcachofa es una planta rica en fibras, flavonoides y antioxidantes, que aporta minerales como sodio, potasio, hierro, magnesio y calcio y vitaminas como la C, A y ácido fólico. Esta planta puede comprarse en tiendas de productos naturales, supermercados y mercados municipales.', 'Cynara scolymus', 0, 'https://static.tuasaude.com/media/article/ba/so/alcachofra_4003_l.jpg', 0, 'ycarrillo'),
(15, 'Cardo Mariano', '                El cardo mariano es un poderoso desintoxicante por su gran capacidad para contribuir a la regeneración de las células del hígado. Es un remedio efectivo contra los efectos nocivos del consumo de alcohol, los pesticidas, metales pesados o la contaminación ambiental.    \r\n  \r\nPrecauciones con el cardo mariano\r\n\r\nEl cardo mariano puede provocar un efecto laxante si se toma en dosis altas o inadecuadas. No se recomienda tomar cardo mariano en caso de hipertensión arterial por su efecto hipertensor en pacientes que sigan tratamientos antidepresivos      ', 'Silybum marianum', 0, 'https://as.com/deporteyvida/imagenes/2018/02/25/portada/1519581486_046201_1519581577_noticia_normal.jpg', 0, 'ycarrillo'),
(16, 'Cannabis', '                      Cannabis sativa,nota ​ cáñamo o marihuana, es una especie herbácea de la familia Cannabaceae. Es una planta anual, dioica, originaria de las cordilleras del Himalaya, Asia.\r\n\r\nLos humanos han cultivado desde tiempos prehistóricos esta planta por sus numerosos usos: como fuente de fibra textil, para extraer el aceite de sus semillas, como planta medicinal —hay registros escritos sobre este uso que datan de 2737 a. C.y como psicotrópico y herramienta mística y espiritual.\r\n\r\nSu fibra tiene usos variados, incluyendo la manufactura de vestimenta, cuerdas, textiles industriales y para obtener pasta de papel. El aceite de sus semillas —los cañamones— que no contiene cannabinoides se puede usar como combustible y alimento. Las semillas enteras, o los restos que quedan tras la extracción del aceite se usan como alimento para mascotas y para el ganado.      ', 'Cannabis sativa', 0, 'https://www.drugabuse.gov/sites/default/files/styles/content_image_medium/public/marijuana-from-marijuana-farm.jpg?itok=fYbo_Swt', 0, 'ycarrillo'),
(17, 'Calendula', '                      De la caléndula se aprovechan con fines medicinales sus capítulos florales, que se deben cosechar cuando están en plena floración y, si es posible, en las primeras horas del día tras la salida del sol. A esta planta se le atribuye una notable actividad antiinflamatoria, y se muestra asimismo como antiséptica, antiviral, antibacteriana, antiespasmódica, emenagoga, colerética, antihemorrágica y cicatrizante.\r\n\r\nLos expertos recomiendan ceñir el uso de la caléndula a aplicaciones por vía tópica, pero se mantienen vivos algunos de sus usos tradicionales por vía interna, como veremos. A continuación detallamos sus principales indicaciones.      ', 'Calendula officinalis', 0, 'https://www.hogarmania.com/archivos/202010/calendula-planta-medicinal-con-grandes-beneficios-1280x720x80xX.jpg', 0, 'ycarrillo'),
(18, 'Stevia ', '                      La planta Stevia rebaudiana tiene una larga historia de uso etnomédico por los guaraníes, habiendo sido utilizada ampliamente por ellos desde hace más de 1.500 años.  Las hojas se han utilizado tradicionalmente durante cientos de años en Paraguay para endulzar tés locales y medicamentos.\r\n\r\nEn 1899 el botánico suizo Moisés Santiago Bertoni, lo identificó taxonómicamente mientras realizaba investigaciones en el este de Paraguay,8fue quien le dio el nombre de Stevia en honor al botánico, médico y humanista valenciano del siglo XVI Pedro Jaime Esteve, quien la investigó por primera vez con la llegada de las nuevas especies de plantas a España. Sólo se llevó a cabo una investigación limitada sobre el tema hasta que en 1931 dos químicos franceses aislaron los glucósidos de la estevia que dan su sabor dulce      ', 'Stevia rebaudiana', 0, 'https://s1.eestatic.com/2017/09/18/ciencia/salud/diabetes-corazon-cardiologia_247738053_47193854_1024x576.jpg', 0, 'ycarrillo'),
(19, 'Flor De Jamaica ', '                      La flor o caliz de jamaica es, como su nombre lo indica, la flor de la planta arbustiva (Hibiscus sabdariffa L.) perteneciente a la familia Malvaceae.\r\n\r\nEs originaria de Asia y África tropical, y actualmente se conoce más de medio millón de especies en el mundo. \r\nEn algunas regiones las flores son rojas y en otras verdes.\r\n\r\nActualmente, China encabeza su producción, seguido de India, Sudán, Uganda, Indonesia, Malasia y en séptimo lugar se encuentra México.\r\n\r\nEl estado de mayor producción de jamaica en el país es Guerrero (con aproximadamente el 75% de la producción), seguido de Oaxaca, Michoacán, Nayarit y Puebla, principalmente.\r\n\r\nLas variedades más cultivadas en México son la criolla, la china, jerzy y sudán.\r\n\r\nLa flor de jamaica mexicana es cultivada por pequeños productores, su cosecha es en forma manual, aumentando el costo de producción que compite con los bajos precios de jamaica importadas.      ', 'Hibiscus sabdariffa', 0, 'https://www.mundosano.com/__export/1591976891611/sites/elimparcial/img/2020/06/12/flor_de_jamaica.png_554688468.png', 0, 'ycarrillo'),
(20, 'Centella asiática', '                      La centella asiática es una planta medicinal con diversos beneficios para la salud, entre ellos, principalmente, contribuye a potenciar la producción de colágeno, la proteína que interviene en la piel, en las articulaciones, los huesos y los músculos. Aporta dureza y firmeza a estos tejidos y detiene la flaccidez.      ', 'hidrocotyle asiática', 0, 'https://previews.123rf.com/images/kittikornphongok/kittikornphongok1605/kittikornphongok160500100/56880232-planta-de-centella-asiatica-hoja-centella-asi%C3%A1tica-.jpg', 0, 'ycarrillo'),
(30, 'a1', '	a4						', 'a2', 0, 'a3', 0, 'usuario20');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `usuarioId` int(11) NOT NULL,
  `nombreUsuario` varchar(30) NOT NULL,
  `clave` varchar(255) NOT NULL,
  `roleId` int(255) NOT NULL,
  `activo` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`usuarioId`, `nombreUsuario`, `clave`, `roleId`, `activo`) VALUES
(2, 'jcarrillo', '13562e0e735efa8c8b3995bf489f1507467f94cff148c64a0d8ec36c6a561b41', 1, 1),
(3, 'administrador', '0ead2060b65992dca4769af601a1b3a35ef38cfad2c2c465bb160ea764157c5d', 1, 1),
(8, 'usuario1', '13562e0e735efa8c8b3995bf489f1507467f94cff148c64a0d8ec36c6a561b41', 2, 1),
(9, 'ycarrillo', '', 2, 1),
(10, 'usuario2', '13562e0e735efa8c8b3995bf489f1507467f94cff148c64a0d8ec36c6a561b41', 2, 1),
(11, 'usuario20', '0ead2060b65992dca4769af601a1b3a35ef38cfad2c2c465bb160ea764157c5d', 1, 1),
(12, 'usuario3', 'd74a5f8287bb941c9fb78ec10debdfe5a986b4c6540504a4cc2d0395fd05e838', 2, 1),
(13, 'usuario5', 'ff960cb55673958c594d0daaab1e368651c75c02f9687192a1811e7b180336a7', 2, 1),
(14, 'LUISHALL', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4', 2, 1),
(20, 'LUISHALL1', '5994471abb01112afcc18159f6cc74b4f511b99806da59b3caf5a9c173cacfc5', 2, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuariorole`
--

CREATE TABLE `usuariorole` (
  `usuarioRoleId` int(11) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `ultimaActualizacionPor` varchar(255) NOT NULL,
  `fechaUltimaActualizacion` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `usuariorole`
--

INSERT INTO `usuariorole` (`usuarioRoleId`, `nombre`, `activo`, `ultimaActualizacionPor`, `fechaUltimaActualizacion`) VALUES
(1, 'Administrador', 1, '', '2021-04-21 22:10:27'),
(2, 'Operador', 1, '', '2021-04-21 22:10:49');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `producto`
--
ALTER TABLE `producto`
  ADD PRIMARY KEY (`productoId`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`usuarioId`),
  ADD UNIQUE KEY `nombreUsuario` (`nombreUsuario`),
  ADD KEY `usuario_fk0` (`roleId`);

--
-- Indices de la tabla `usuariorole`
--
ALTER TABLE `usuariorole`
  ADD PRIMARY KEY (`usuarioRoleId`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `producto`
--
ALTER TABLE `producto`
  MODIFY `productoId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `usuarioId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `usuariorole`
--
ALTER TABLE `usuariorole`
  MODIFY `usuarioRoleId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD CONSTRAINT `usuario_fk0` FOREIGN KEY (`roleId`) REFERENCES `usuariorole` (`usuarioRoleId`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
