<?php
	//Recibo parámetros por POST
	$usuario = $_POST["un"];
	$clave = $_POST["up"];
	//Encripto parámetros
	$claveE = hash("sha256", $clave);
	//CONEXIÓN CON NOTACIÓN POR OBJETO
	//1. Crear un objeto de conexión de tipo mysqli
	$conn = mysqli_connect("localhost","proyecto","Liga.Liga","proyecto");
	//2. Verificar conexión
	if($conn->connect_error){
		//Hubo error en la conexión con la base de datos
		echo "ERROR";
	}else{
		//Conexión Correcta. Ejecuto mis comandos.
		//Configuración de la codificación de los carácteres
		$conn->set_charset("utf8");
		//Redacto String con COMANDO SQL
		$insertar = "INSERT INTO `usuario`(`nombreUsuario`, `clave`,roleId, activo ) VALUES ('$usuario','$claveE',2,1)";
		//Ejecuto COMANDO SQL
		$respuesta = $conn->query($insertar);
		//Leo respuesta
		if($respuesta == true){
			session_start();
			//$_SESSION["usuarioActivoID"] = $usuarioID;
			$_SESSION["usuarioActivoNombre"] = $usuario;
			echo "OK";
		}else{
			echo "ERROR";
		}
	}

	//echo "MENSAJE RECIBIDO: $usuario - $claveE";
	mysqli_close($conn);
?>