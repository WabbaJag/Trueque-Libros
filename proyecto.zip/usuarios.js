function cargarUsuarios(){
	//1. Crear: Comprar el sobre
	var carta = new XMLHttpRequest();
	//2. Configurar: Privacidad, Dirección y Mensaje
	carta.open("GET","obtenerUsuarios.php",true);
	//3. Envío:
	carta.send(null);

	//Recibir respuesta del servidor - Atributos de XMLHttpRequest
	carta.onreadystatechange = function() {
		if(carta.readyState == 4 && carta.status == 200){
			//document.getElementById("hContenido").innerHTML = carta.responseText;
			var div = document.getElementById("hContenido");
		    var data = JSON.parse(carta.responseText);
			let i=1;

			//Crear Encabezados de la tabla
			/*var rowEnc = div.appendChild(document.createElement('div'));
			rowEnc.className = "row";
			rowEnc.id = "rowEncabezado";

			var box = rowEnc.appendChild(document.createElement('div'));
			box.className = "col-4";
			var textnode = document.createTextNode( "Id" ); 
			box.appendChild(textnode);

			var box = rowEnc.appendChild(document.createElement('div'));
			box.className = "col-4";
			var textnode = document.createTextNode( "Nombre" ); 
			box.appendChild(textnode);

			var box = rowEnc.appendChild(document.createElement('div'));
			box.className = "col-4";
			var textnode = document.createTextNode( "" );
			box.appendChild(textnode);*/

		    for(var fila in data){
				var row = div.appendChild(document.createElement('div'));
    			row.className = "row";
    			row.id = "row" + i;
				i++;

				var box = row.appendChild(document.createElement('div'));
        		box.className = "col-3 textoGrid";
				var textnode = document.createTextNode( data[fila].usuarioId ); 
				box.appendChild(textnode);

				var box = row.appendChild(document.createElement('div'));
        		box.className = "col-3 textoGrid";
				var textnode = document.createTextNode( data[fila].nombreUsuario ); 
				box.appendChild(textnode);

				var box = row.appendChild(document.createElement('div'));
        		box.className = "col-3 textoGrid";
				var textnode = document.createTextNode( data[fila].role ); 
				box.appendChild(textnode);				

				var box = row.appendChild(document.createElement('div'));
        		box.className = "col-3 textoGrid";
				var a = document.createElement('a'); 
				var link = document.createTextNode("Editar");
				a.appendChild(link); 
				a.href = "editarUsuario.html?usuarioId=" + data[fila].usuarioId; 
				box.appendChild(a);

				
				//div.appendChild(row);
		    }
		}
	}
}

function cargarUsuarioActivo(){
	//1. Crear: Comprar el sobre
	var carta = new XMLHttpRequest();
	//2. Configurar: Privacidad, Dirección y Mensaje
	carta.open("GET","obtenerUsuario.php",true);
	//3. Envío:
	carta.send(null);

	//Recibir respuesta del servidor - Atributos de XMLHttpRequest
	carta.onreadystatechange = function() {

		if(carta.readyState == 4 && carta.status == 200){
			document.getElementById("nombreUsuario").innerText = carta.responseText;
		}
	}
}

function cargarInfoPantalla() {
	cargarUsuarioActivo();
	cargarUsuarios();
}